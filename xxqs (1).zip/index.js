const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => res.send('sex'));

app.listen(port, () =>
  console.log(`Your app is listening at http://localhost:${port}`)
);

const Discord = require('discord.js');
const client = new Discord.Client();

const prefix = '!'; // Bot Prefix
const statuses = ['24/7']; // Bot Status
const timers = 2;
const owners = ['923316733312376904']; // Bot Owners

client.login('MTAzNjg5NjMyMTExNTc4NzMzNA.G8cAMt.01uNHsL3T9jCCzX-P0Usqpz8ECoxUeoDc5W0Cs'); // Replace with your actual bot token

client.on('ready', () => {
  console.log(`Signed in: ${client.user.tag}`);
  client.user.setStatus('dnd');
  const timeing = Math.floor(timers * 1000);
  setInterval(function () {
    const lengthesof = statuses.length;
    const amounter = Math.floor(Math.random() * lengthesof);
    client.user.setActivity(statuses[amounter], { type: '' });
  }, timeing);
});

client.on('message', (message) => {
  if (message.content.toLowerCase().startsWith(prefix + 'help')) {
    message.react('✔');
    const help = new Discord.MessageEmbed()
      .setTimestamp()
      .setAuthor(
        message.author.username,
        message.author.displayAvatarURL({ dynamic: true })
      )
      .setFooter('Developed by Jason', client.user.displayAvatarURL())
      .setThumbnail(client.user.displayAvatarURL())
      .setDescription(
        `> **${client.user.username} Help Commands\n> Active Commands: "6" Prefix\n> Prefix: \`${prefix}\`**\n> **Language: English**`
      )
      .addFields(
        {
          name: 'admins',
          value: `\`${prefix}bc\`, \`${prefix}obc\`, \`${prefix}ping\``,
        },
        {
          name: 'Owners',
          value: `\`${prefix}setname\`, \`${prefix}setavatar\``,
        },
        {
          name: 'Extra',
          value: '`invite`, `help`',
        }
      );
    message.channel.send(help);
  }

  if (message.content.startsWith(prefix + 'bc')) {
    if (!message.member.hasPermission('ADMINISTRATOR')) return;

    message.delete();
    const args = message.content
      .split(' ')
      .slice(1)
      .join(' ');
    const noargs = new Discord.MessageEmbed()
      .setAuthor(
        message.author.username,
        message.author.displayAvatarURL({ dynamic: true })
      )
      .addField('Error :x:', 'Enter a valid message!')
      .setTimestamp()
      .setFooter(
        message.author.username,
        message.author.displayAvatarURL({ dynamic: true })
      );
    if (!args) return message.channel.send(message.author, noargs);
    message.guild.members.cache
      .filter((m) => m.presence.status !== 'everyone')
      .forEach((m) => {
        if (m.user.bot) return;
        m.send(`${args}\n ${m}`)
          .then(() => {
            console.log(`I sent this: ${m.user.tag} ✅`);
          })
          .catch(function () {
            console.log(`blocked: ${m.user.tag} ❌ `);
          });
      });
    const embedMessage = new Discord.MessageEmbed()
      .setColor('#0099ff')
      .setTitle('Broadcast Command')
      .setDescription('Your broadcast message has been sent to all members.')
      .setTimestamp();
    message.channel.send(embedMessage);
  }

  if (message.content.startsWith(prefix + 'obc')) {
    if (!message.member.hasPermission('ADMINISTRATOR')) return;

    message.delete();
    const args = message.content
      .split(' ')
      .slice(1)
      .join(' ');
    const noargs = new Discord.MessageEmbed()
      .setAuthor(
        message.author.username,
        message.author.displayAvatarURL({ dynamic: true })
      )
      .addField('Error :x:', 'Please enter a valid message!')
      .setTimestamp()
      .setFooter(
        message.author.username,
        message.author.displayAvatarURL({ dynamic: true })
      );
    if (!args) return message.channel.send(message.author, noargs);
    message.guild.members.cache
      .filter((m) => m.presence.status !== 'offline')
      .forEach((m) => {
        if (m.user.bot) return;
        m.send(`${args}\n ${m}`)
          .then(() => {
            console.log(`I was able to send: ${m.user.tag} ✅`);
          })
          .catch(function () {
            console.log(`done: ${m.user.tag} ❌ `);
          });
      });
    const embedMessage = new Discord.MessageEmbed()
      .setColor('#0099ff')
      .setTitle('Online Broadcast Command')
      .setDescription(
        'Your online broadcast message has been sent to all online members.'
      )
      .setTimestamp();
    message.channel.send(embedMessage);
  }

  if (message.content.startsWith(prefix + 'ping')) {
    message.channel.send('Ping..').then((m) => {
      m.edit(
        `\`\`\`javascript\nDiscord API: ${Math.round(client.ws.ping)} ms\n\`\`\``
      );
    });
  }
  if (message.content.startsWith(prefix + 'invite')) {
    message.channel.send('Generating invite link...').then((m) => {
      const embed = new Discord.MessageEmbed()
        .setAuthor(
          message.author.username,
          message.author.displayAvatarURL({ dynamic: true })
        )
        .setTitle('Invite Here')
        .setURL(
          `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`
        )
        .setTimestamp()
        .setFooter(
          message.author.username,
          message.author.displayAvatarURL({ dynamic: true })
        );
      m.edit(embed);
    });
  }

  if (message.content.startsWith(prefix + 'setname')) {
    const args = message.content.split(' ');
    const botnameee = args.slice(1).join(' ');
    if (!owners.includes(message.author.id))
      return message.channel.send('** :x: Only bot owners can use this command **');
    if (!botnameee)
      return message.channel.send('** :x: Specify a name !**');
    client.user.setUsername(`${botnameee}`);
    message.channel.send(`Changing the bot's name...`).then((me) => {
      me.edit(`Done!`);
    });
  }
  if (message.content.startsWith(prefix + 'setavatar')) {
    const args = message.content.split(' ');
    const botnameee = args.slice(1).join(' ');
    if (!owners.includes(message.author.id))
      return message.channel.send('** :x: Only bot owners can use this command **');
    if (!botnameee)
      return message.channel.send('** :x: Please select a valid profile picture !**');
    client.user.setAvatar(`${botnameee}`);
    message.channel.send(`Bot's profile picture changing...`).then((me) => {
      me.edit(`Done!`);
    });
  }
});